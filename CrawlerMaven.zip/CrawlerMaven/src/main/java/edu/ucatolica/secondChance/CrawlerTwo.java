package edu.ucatolica.secondChance;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class CrawlerTwo {

    // final static String authUser = "CO-ATTLA\\EIG9782A";
    // final static String authPassword = "Kibyrana2006ud";
    static List<NodoPage> urls = new ArrayList<NodoPage>();

    public static void main(String[] args) {
        crawler("http://unal.edu.co");
    }
    private static NodoPage nodos = new NodoPage();

    public static void crawler(String URL) {
        //get useful information
        try {

//			System.setProperty("http.proxySet", "true");
//			Authenticator.setDefault(new ProxyAuthenticator("user", "password"));
//            System.getProperties().put("http.proxyHost", "172.31.239.53");
//            System.getProperties().put("http.proxyPort", "3128");

            Document doc = Jsoup.connect(URL).get();
//			System.out.println(doc.toString());
            //if(doc.text().contains("research")){
            System.out.println(URL);
            //}
            //get all links and recursively call the processPage method
            Elements questions = doc.select("a");
            for (Element link : questions) {

                if (link.attr("href").contains("unal.edu.co") && !urls.contains(link.attr("href"))) {
                    nodos.setUrl(link.attr("href"));
                    crawler(link.attr("abs:href"));
                    urls.add(nodos);
                    nodos = new NodoPage();
                }
            }
            
            for (NodoPage a : urls) {
                System.out.println(a.getUrl());
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("total " + urls.size());
    }
}
