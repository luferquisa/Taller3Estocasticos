/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucatolica.secondChance;

/**
 *
 * @author s02e15
 */
public class NodoPage {
    private String url;
    private Integer posicion;
    private NodoPage nodo;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getPosicion() {
        return posicion;
    }

    public void setPosicion(Integer posicion) {
        this.posicion = posicion;
    }

    public NodoPage getNodo() {
        return nodo;
    }

    public void setNodo(NodoPage nodo) {
        this.nodo = nodo;
    }
    
}
